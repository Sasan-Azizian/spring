package springdemo;

public interface FortuneService {

	public String getFortune();
}
