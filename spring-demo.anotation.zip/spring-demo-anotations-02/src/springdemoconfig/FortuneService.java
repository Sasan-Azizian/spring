package springdemoconfig;

public interface FortuneService {

	public String getFortune();
}
